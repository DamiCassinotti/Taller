#ifndef TP1_COMMONS_H
#define TP1_COMMONS_H

#include <stdio.h>
#include <string.h>
#include <stdbool.h>

int getIntFromBytes(char *bytes);

short getShortFromBytes(char *bytes);

#endif //TP1_COMMONS_H
