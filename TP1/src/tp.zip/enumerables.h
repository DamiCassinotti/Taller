#ifndef TP1_ENUMERABLES_H
#define TP1_ENUMERABLES_H

enum tipoNodo {
    no_hoja, hoja
};
typedef enum tipoNodo tipoNodo;

#endif //TP1_ENUMERABLES_H
